import React from "react";
import "./App.css";
import WebUiOne from "./WebUiOne";

const App = () => (
  <div>
    <WebUiOne />
    <div>
      <h1>IS THIS SCROLLING??</h1>
    </div>
  </div>
);

export default App;
